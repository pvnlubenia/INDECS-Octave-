% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                             %
%    Example 1                                                                %
%                                                                             %
%                                                                             %
% This is Example 8 in Hernandez and De la Cruz (2021): Generalized mass      %
%    action model of anaerobic fermentation pathway of Saccharomyces          %
%    cerevisiae                                                               %
%                                                                             %
% RESULT: The independent decomposition of the network of 13 reactions        %
%            contains 2 partitions.                                           %
%                                                                             %
% Reference: Hernandez B, De la Cruz R (2021) Independent decompositions of   %
%    chemical reaction networks. Bull Math Biol 83(76):1–23.                  %
%    https://doi.org/10.1007/s11538-021-00906-3                               %
%                                                                             %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Example 1';
model.species = { }; % do not fill out; will be filled automatically by 'indep_decomp'
model.reaction(1) = struct('id', 'X2->X1+X2', 'reactant', struct('species', {'X2'}, 'stoichiometry', {1}), 'product', struct('species', {'X1', 'X2'}, 'stoichiometry', {1, 1}), 'reversible', false);
model.reaction(2) = struct('id', 'X1+X5->X2+X5', 'reactant', struct('species', {'X1', 'X5'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'X2', 'X5'}, 'stoichiometry', {1, 1}), 'reversible', false);
model.reaction(3) = struct('id', '2X5+X1->X5+X1', 'reactant', struct('species', {'X5', 'X1'}, 'stoichiometry', {2, 1}), 'product', struct('species', {'X5', 'X1'}, 'stoichiometry', {1, 1}), 'reversible', false);
model.reaction(4) = struct('id', 'X2+X5->X3+X5', 'reactant', struct('species', {'X2', 'X5'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'X3', 'X5'}, 'stoichiometry', {1, 1}), 'reversible', false);
model.reaction(5) = struct('id', '2X5+X2->X5+X2', 'reactant', struct('species', {'X5', 'X2'}, 'stoichiometry', {2, 1}), 'product', struct('species', {'X5', 'X2'}, 'stoichiometry', {1, 1}), 'reversible', false);
model.reaction(6) = struct('id', 'X2+X5->X5', 'reactant', struct('species', {'X2', 'X5'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'X5'}, 'stoichiometry', {1}), 'reversible', false);
model.reaction(7) = struct('id', 'X2+X5->X2', 'reactant', struct('species', {'X2', 'X5'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'X2'}, 'stoichiometry', {1}), 'reversible', false);
model.reaction(8) = struct('id', 'X3+X5->X4+X5', 'reactant', struct('species', {'X3', 'X5'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'X4', 'X5'}, 'stoichiometry', {1, 1}), 'reversible', false);
model.reaction(9) = struct('id', 'X3+X5->X3+2X5', 'reactant', struct('species', {'X3', 'X5'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'X3', 'X5'}, 'stoichiometry', {1, 2}), 'reversible', false);
model.reaction(10) = struct('id', 'X3+X4+X5->X4+X5', 'reactant', struct('species', {'X3', 'X4', 'X5'}, 'stoichiometry', {1, 1, 1}), 'product', struct('species', {'X4', 'X5'}, 'stoichiometry', {1, 1}), 'reversible', false);
model.reaction(11) = struct('id', 'X3+X4+X5->X3+X5', 'reactant', struct('species', {'X3', 'X4', 'X5'}, 'stoichiometry', {1, 1, 1}), 'product', struct('species', {'X3', 'X5'}, 'stoichiometry', {1, 1}), 'reversible', false);
model.reaction(12) = struct('id', 'X3+X4+X5->X3+X4+2X5', 'reactant', struct('species', {'X3', 'X4', 'X5'}, 'stoichiometry', {1, 1, 1}), 'product', struct('species', {'X3', 'X4', 'X5'}, 'stoichiometry', {1, 1, 2}), 'reversible', false);
model.reaction(13) = struct('id', '2X5->X5', 'reactant', struct('species', {'X5'}, 'stoichiometry', {2}), 'product', struct('species', {'X5'}, 'stoichiometry', {1}), 'reversible', false);

% Generate the independent decomposition
[model, R, G, P] = indep_decomp(model);
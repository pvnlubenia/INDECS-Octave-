# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#                                                                             #
#    init_graph                                                               #
#                                                                             #
#                                                                             #
# OUTPUT: Creates an empty structure that represents an undirected graph. The #
#            structure has the following fields: 'vertices' and 'edges'.      #
# INPUT: none                                                                 #
#                                                                             #
# Created: 18 July 2021                                                       #
# Last Modified: 20 July 2021                                                 #
#                                                                             #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #



function g = init_graph()
    
    % Initialize a structure with empty fields
    g = struct();
    
    % Initialize 'vertices' field
    g.vertices = cell();
    
    % Initialize 'edges' field
    g.edges = cell();
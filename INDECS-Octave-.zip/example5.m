% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                             %
%    Example 5                                                                %
%                                                                             %
%                                                                             %
% This is Example 12 in Hernandez and De la Cruz (2021): Handel influenza     %
%    virus model                                                              %
%                                                                             %
% RESULT: The independent decomposition of the network of 12 reactions        %
%            contains 4 partitions.                                           %
%                                                                             %
% Reference: Hernandez B, De la Cruz R (2021) Independent decompositions of   %
%    chemical reaction networks. Bull Math Biol 83(76):1–23.                  %
%    https://doi.org/10.1007/s11538-021-00906-3                               %
%                                                                             %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Example 5';
model.species = { }; % do not fill out; will be filled automatically by 'indep_decomp'
model.reaction(1) = struct('id', 'D->U', 'reactant', struct('species', {'D'}, 'stoichiometry', {1}), 'product', struct('species', {'U'}, 'stoichiometry', {1}), 'reversible', false);
model.reaction(2) = struct('id', 'U+V->E+V', 'reactant', struct('species', {'U', 'V'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'E', 'V'}, 'stoichiometry', {1, 1}), 'reversible', false);
model.reaction(3) = struct('id', 'E->I', 'reactant', struct('species', {'E'}, 'stoichiometry', {1}), 'product', struct('species', {'I'}, 'stoichiometry', {1}), 'reversible', false);
model.reaction(4) = struct('id', 'I->D', 'reactant', struct('species', {'I'}, 'stoichiometry', {1}), 'product', struct('species', {'D'}, 'stoichiometry', {1}), 'reversible', false);
model.reaction(5) = struct('id', 'I->I+V', 'reactant', struct('species', {'I'}, 'stoichiometry', {1}), 'product', struct('species', {'I', 'V'}, 'stoichiometry', {1, 1}), 'reversible', false);
model.reaction(6) = struct('id', 'V->0', 'reactant', struct('species', {'V'}, 'stoichiometry', {1}), 'product', struct('species', { }, 'stoichiometry', { }), 'reversible', false);
model.reaction(7) = struct('id', 'U+V->U', 'reactant', struct('species', {'U', 'V'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'U'}, 'stoichiometry', {1}), 'reversible', false);
model.reaction(8) = struct('id', 'V+X->X', 'reactant', struct('species', {'V', 'X'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'X'}, 'stoichiometry', {1}), 'reversible', false);
model.reaction(9) = struct('id', 'V->V+F', 'reactant', struct('species', {'V'}, 'stoichiometry', {1}), 'product', struct('species', {'V', 'F'}, 'stoichiometry', {1, 1}), 'reversible', false);
model.reaction(10) = struct('id', 'F->0', 'reactant', struct('species', {'F'}, 'stoichiometry', {1}), 'product', struct('species', { }, 'stoichiometry', { }), 'reversible', false);
model.reaction(11) = struct('id', 'V->V+X', 'reactant', struct('species', {'V'}, 'stoichiometry', {1}), 'product', struct('species', {'V', 'X'}, 'stoichiometry', {1, 1}), 'reversible', false);
model.reaction(12) = struct('id', 'X->2X', 'reactant', struct('species', {'X'}, 'stoichiometry', {1}), 'product', struct('species', {'X'}, 'stoichiometry', {2}), 'reversible', false);

% Generate the independent decomposition
[model, R, G, P] = indep_decomp(model);
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                             %
%    Example 4                                                                %
%                                                                             %
%                                                                             %
% This is Example 11 in Hernandez and De la Cruz (2021): Baccam influenza     %
%    virus model with delayed virus production                                %
%                                                                             %
% RESULT: The independent decomposition of the network of 5 reactions         %
%            contains 4 partitions.                                           %
%                                                                             %
% Reference: Hernandez B, De la Cruz R (2021) Independent decompositions of   %
%    chemical reaction networks. Bull Math Biol 83(76):1–23.                  %
%    https://doi.org/10.1007/s11538-021-00906-3                               %
%                                                                             %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Example 4';
model.species = { }; % do not fill out; will be filled automatically by 'indep_decomp'
model.reaction(1) = struct('id', 'T+V->I1+V', 'reactant', struct('species', {'T', 'V'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'I1', 'V'}, 'stoichiometry', {1, 1}), 'reversible', false);
model.reaction(2) = struct('id', 'I1->I2', 'reactant', struct('species', {'I1'}, 'stoichiometry', {1}), 'product', struct('species', {'I2'}, 'stoichiometry', {1}), 'reversible', false);
model.reaction(3) = struct('id', 'I2->0', 'reactant', struct('species', {'I2'}, 'stoichiometry', {1}), 'product', struct('species', { }, 'stoichiometry', { }), 'reversible', false);
model.reaction(4) = struct('id', 'I2->I2+V', 'reactant', struct('species', {'I2'}, 'stoichiometry', {1}), 'product', struct('species', {'I2', 'V'}, 'stoichiometry', {1, 1}), 'reversible', false);
model.reaction(5) = struct('id', 'V->0', 'reactant', struct('species', {'V'}, 'stoichiometry', {1}), 'product', struct('species', { }, 'stoichiometry', { }), 'reversible', false);

% Generate the independent decomposition
[model, R, G, P] = indep_decomp(model);
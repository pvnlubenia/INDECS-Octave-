# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#                                                                             #
#    vertex_component                                                         #
#                                                                             #
#                                                                             #
# OUTPUT: Returns a vector whose entries are the component numbers where each #
#            vertex of an undirected graph belongs to. The function returns   #
#            an empty value if there are no vertices in the graph.            #
# INPUT: g: a structure with fields 'vertices' and 'edges'                    #
#                                                                             #
# Reference: Soranzo, N. and Altafini, C. (2009). ERNEST: a toolbox for       #
#               chemical reaction network theory. Bioinformatics, 25(21),     #
#               2853–2854. doi:10.1093/bioinformatics/btp513.                 #
#                                                                             #
# Created: 19 July 2021                                                       #
# Last Modified: 21 July 2021                                                 #
#                                                                             #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #



function c = vertex_component(g)
    
    % Initialize the vector which will indicate which component number a vertex belongs to
    c = zeros(numel(g.vertices), 1);
    
    % Initialize the component number tracker
    c_num = 0;
    
    % Go to each vertex
    for i = 1:numel(g.vertices)
        
        % Pay attention only to a vertex which has no component number yet
        if c(i) == 0
            
            % This vertex goes to the next component number
            c_num += 1;
            
            % Assign the component number to the vertex
            c(i) = c_num;
            
            % Take note of the vertex that needs to be checked for edges
            to_check = [i];
            
            % Continue assigning a component number to vertices that get into the check list
            while ~isempty(to_check)
                
                % Get the vertex in the check list
                v1 = to_check(end);
                
                % Remove the vertex from the check list (since we now know which vertex to focus on)
                to_check(end) = [ ];
                
                % Check to which vertices the vertex is connected to
                for j = 1:numel(g.edges{v1})
                    
                    % Take note of the vertex it is connected to
                    v2 = g.edges{v1}(j).vertex;
                    
                    % Pay attention to this vertex if it has no component number yet
                    if c(v2) == 0
                        
                        % Assign this vertex with the same component number as the vertex it is connected to
                        c(v2) = c_num;
                        
                        % Add this vertex to our check list: in the next round, we'll check to which other vertices it is connected to
                        to_check(end+1) = v2;
                    end
                end
            end
        end
    end